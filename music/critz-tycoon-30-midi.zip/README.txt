Critz: Tycoon — A Tiny World
30 original Type-1 MIDI compositions.
480 PPQ; separate named parts; GM fallback programs; pitch-bend range +/-2 semitones.
LOOP_START / LOOP_END are suggested musical loop regions; coda follows.
MIDI stores performance, not audio. The listening-room MP3s use original custom synth patches.
Original composition/arrangement: Codex for Critz: Tycoon, MUSIC.01 review edition.
No Pokemon recordings, melodies or game samples included.
