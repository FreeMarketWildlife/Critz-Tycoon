Four 32x64 front-idle sprites; anchor 16,64. Open editor/*.sprite.json in the Sprite Editor. Animation not included. Awaiting visual approval; reference Brendan excluded.
